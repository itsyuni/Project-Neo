<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class Calculator extends AbstractForm
{

    /**
     * @event circle3.click-Left 
     */
    function doCircle3ClickLeft(UXMouseEvent $e = null)
    {    
        
    }


}
